using Photon.Pun.Demo.SlotRacer;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    public GameObject inventoryObject;
    public GameObject InvenCtrl;
    public Slot[] slots;
    public static GameObject[] InventorySlot; 

    private Vector3 originalScale;
    private Vector3 hiddenScale;
    private Item[] collectedItems; // 획득한 아이템을 추적하기 위한 배열
    private int itemCount; // 현재 획득한 아이템의 수

    void Start()
    {
        originalScale = new Vector3(1, 1, 1);
        hiddenScale = new Vector3(0, 0, 0);

        GameObject[] TraitBoxes = GameObject.FindGameObjectsWithTag("TraitBox");
        InvenCtrl = GameObject.Find("InventoryCtrl");

        slots = new Slot[TraitBoxes.Length];

        for(int i = 0; i < TraitBoxes.Length; i++) 
        {
            slots[i] = TraitBoxes[i].GetComponent<Slot>();
        }

        collectedItems = new Item[slots.Length]; // 슬롯 개수와 같은 크기의 배열로 초기화
        itemCount = 0;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.I))
        {
            AddItem(SecretShop.slotsItem);
        }
    }

    public void AddItem(Item itemToBeAdded, Item startingItem = null)
    {
        // 이미 획득한 아이템인지 확인
        for (int i = 0; i < itemCount; i++)
        {
            if (collectedItems[i].itemID == itemToBeAdded.itemID)
            {
                Debug.Log("이미 획득한 아이템입니다: " + itemToBeAdded.name);
                return;
            }
        }

        // 획득한 아이템을 배열에 추가
        collectedItems[itemCount] = itemToBeAdded;
        itemCount++;

        List<Slot> emptySlots = new List<Slot>();

        foreach(Slot i in slots)
        {
            emptySlots.Add(i);
        }

        if(emptySlots.Count > 0)
        {
            itemToBeAdded.transform.parent = emptySlots[itemToBeAdded.SlotIndex].transform;
            itemToBeAdded.gameObject.SetActive(false);
            Debug.Log("아이템이 추가되었습니다: " + itemToBeAdded.name);
        }
        else
        {
            Debug.Log("빈 슬롯이 없습니다: " + itemToBeAdded.name);
        }
    }

    private void OnTriggerEnter(Collider col) 
    {
        if (col.GetComponent<Item>())
        {
            Debug.Log("아이템 감지됨: " + col.GetComponent<Item>().name);
            AddItem(col.GetComponent<Item>());
        }
    }
}